package com.ultraperformance.torcherino;

import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;

/**
 * Optional Torcherino addon.
 *
 * This milestone only detects the target mod. Actual tick interception is
 * deliberately not enabled until a version-specific hook is implemented and
 * tested; changing accelerated machine behavior without that hook is unsafe.
 */
@Mod(TorcherinoCompat.MOD_ID)
public final class TorcherinoCompat {
    public static final String MOD_ID = "ultra_performance_torcherino";
    public static final String TARGET_MOD_ID = "torcherino";

    private final boolean torcherinoPresent;

    public TorcherinoCompat() {
        this.torcherinoPresent = ModList.get().isLoaded(TARGET_MOD_ID);
    }

    public boolean isTorcherinoPresent() {
        return torcherinoPresent;
    }
}
