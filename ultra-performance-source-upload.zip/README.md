# ULTRA PERFORMANCE 0.6.0

Target: Minecraft Java 1.20.1, Forge 47.x, Java 17.

## Current optimization
The mod can skip rendering non-player living entities beyond a configurable distance. This is client-side visual culling only: it does not pause AI, movement, collision, entity ticks, farms, or server simulation. It may reduce rendering work in entity-heavy scenes, but does not guarantee higher FPS.

## Diagnostics
The read-only diagnostics report client/server tick timing, render-tick proxy timing, JVM heap/GC, entity counts, block events, and client/server chunk load/unload event counts. Version 0.6.0 additionally reports `entityRenderCulled`, the number of living-entity render events canceled by UP during each interval.

`entityRenderCulled` counts activations; it is not a measurement of time saved. Chunk load/unload counters count Forge events and do not directly measure terrain-generation duration. The render-tick proxy is not a GPU frame-time measurement.

## Build
Run `gradle build` with Java 17 and ForgeGradle dependencies available. The GitHub Actions workflow in this repository compiles the main mod and the separate Torcherino compatibility addon.

## Addon
`torcherino-compat/` is an independent addon and remains unchanged in this release.
