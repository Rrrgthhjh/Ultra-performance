# ULTRA PERFORMANCE 0.3.1 — development source

Target: Minecraft Java 1.20.1, Forge 47.x, Java 17.

## Independent projects

- `.` is the main **Ultra Performance** Forge project. It has no dependency on Torcherino or on the compatibility addon.
- `torcherino-compat/` is a separate **Ultra Performance: Torcherino Compatibility** Forge project. It has no dependency on the main mod and only optionally detects Torcherino.

Build each folder separately. Do not treat this repository as one multi-project Gradle build.

## What 0.3.1 actually contains

- Main mod entry point and a registered Forge common configuration file.
- Client-side, read-only performance diagnostics: client tick timing, render-event timing, JVM memory, garbage-collector deltas, and client chunk load/unload event counts. Diagnostics are enabled by default and do not alter game simulation.
- A production-adapter API foundation for future explicitly supported machine integrations.
- Separate Torcherino addon entry point and optional mod-presence detection.

## What it does NOT contain yet

- No FPS, chunk scheduling, entity, particle, or machine-speed optimization is implemented yet. The 0.3.1 diagnostics measure activity; they do not optimize it.
- The Torcherino addon does not intercept accelerated ticks or multiply machine output.
- No compatibility with Draconic Evolution or other machine mods is claimed.
- No compiled JAR is included.

## Build requirements

Use JDK 17 and Gradle with internet access to resolve ForgeGradle and Forge dependencies. The Gradle wrapper is not included.

Main mod, from this folder: `gradle build`

Torcherino addon, from `torcherino-compat/`: `gradle build`

## Testing rules

1. Back up worlds and test in a copied profile.
2. Build and install the main mod alone first.
3. Build and install the addon alone next; it should load even if Torcherino is absent.
4. Only then test the addon with the exact Torcherino build.
5. Do not remove existing mods or libraries based on this development build.

This source has not been compiled or tested in PojavLauncher/LTW. The diagnostic output is intended to help identify bottlenecks before enabling behavior-changing optimizations.

## Compilação automática pelo GitHub Actions

Este projeto inclui `.github/workflows/build.yml`. Depois de enviar a pasta `up020fix` para um repositório GitHub, abra a aba **Actions**, selecione **Build ULTRA PERFORMANCE** e use **Run workflow**. O fluxo configura Java 17 e Gradle 8.8, compila o mod principal e, separadamente, o addon Torcherino, e publica os JARs em **Artifacts**.

A compilação em nuvem ainda precisa ser executada; a presença do workflow não significa que os JARs já foram compilados ou testados no Minecraft.


## 0.3.1 diagnostics

Diagnostics are enabled by default in 0.3.1 and summaries are written to the game log every 10 seconds. You can disable them later in `config/ultra_performance-common.toml` by setting `diagnosticsEnabled = false`. Keep diagnostics disabled for ordinary play if you do not need measurements.

The measurements are observational, not a promise of higher FPS. Render-event timing is an approximate client render-loop measurement, not a GPU-only benchmark. Chunk counters report Forge client chunk load/unload events observed by this mod.


## 0.3.2 diagnostic expansion

This build adds read-only server-side measurements for integrated-server tick duration,
server chunk load/unload events, block break/place events, and entities joining the world
(including item entities). It does not alter tick scheduling, block updates, entity AI,
chunk generation, rendering, or garbage collection. The Torcherino compatibility addon
remains an independent optional project and is unchanged.

## Diagnostics 0.3.4

This build expands read-only diagnostics:
- tick duration averages, maxima, sample counts, and threshold counts;
- interval-based client/server chunk and block event counters;
- entity join/leave counters and tracked current entity categories;
- JVM heap, garbage collector deltas, live/peak thread counts;
- Java, VM, OS, architecture, and processor metadata.

Important limitations:
- renderTick is a render-tick timing proxy, not a guaranteed physical display frame-time measurement;
- entity population counters begin when diagnostics observe entity join events and may not represent entities already present when a world is first entered;
- chunk event counts do not measure chunk-generation duration;
- Android may restrict process, CPU, and device thermal telemetry;
- diagnostics do not identify a specific mod as the cause of a slowdown.


## 0.3.4 timing detail
The timing summary now includes p95 and p99 values for each measured tick category. These percentiles are calculated from up to 2,048 recent samples per category (normally enough for a 30-second interval). If more samples arrive in one interval, the sample buffer keeps the most recent 2,048 while average, maximum, and threshold counters continue to cover every sample. Percentiles are therefore recent-sample estimates, not full-interval percentiles in unusually long/high-frequency intervals.

The render measurement remains a Forge render-tick proxy; it is not a GPU frame-time measurement. The diagnostics are observational and do not identify a specific mod as the cause of a slowdown.
