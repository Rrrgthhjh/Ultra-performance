# ULTRA PERFORMANCE 0.4.0 — first optimization

Target: Minecraft Java 1.20.1, Forge 47.x, Java 17.

## First optimization

The main mod now has an optional client-side rendering optimization: **distant living-entity render culling**. When enabled, non-player living entities farther than the configured distance are not drawn. The default range is 64 blocks.

Important safety boundary: this only cancels the client render event. It does not pause entity ticks, AI, movement, collision, despawning, farms, or server-side simulation. Player entities are excluded. It can make distant mobs, villagers, and animals invisible beyond the selected range. Disable it if this visual trade-off is undesirable.

## Configuration screen

A configuration screen is registered with Forge and should be available through the UP entry in the Mods list (the configuration button). It offers:
- toggle for distant entity render culling;
- distance cycle: 32, 48, 64, 80, 96, 112, 128 blocks.

The screen is placed in Forge's mod configuration UI, **not** directly inside Minecraft's Video Settings page. Adding a button inside Video Settings would require deeper GUI integration/mixin work and is intentionally deferred to avoid modifying vanilla screens in this first optimization.

## Diagnostics

The read-only diagnostics from 0.3.4 remain. Render tick timing is still only a Forge render-tick proxy, not a physical GPU frame-time measurement. The diagnostics do not identify individual mod costs.

## Independent addon

`torcherino-compat/` remains a separate project and is unchanged. The main mod does not require it.

## Validation status

This source package must be compiled by the GitHub Actions workflow and then tested in a copied Minecraft profile/world. No FPS improvement is claimed until A/B measurements are completed on the same device, world, graphics settings, render distance, and test route.
