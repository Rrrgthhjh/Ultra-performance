# ULTRA PERFORMANCE 0.3.0 — development source

Target: Minecraft Java 1.20.1, Forge 47.x, Java 17.

## Independent projects

- `.` is the main **Ultra Performance** Forge project. It has no dependency on Torcherino or on the compatibility addon.
- `torcherino-compat/` is a separate **Ultra Performance: Torcherino Compatibility** Forge project. It has no dependency on the main mod and only optionally detects Torcherino.

Build each folder separately. Do not treat this repository as one multi-project Gradle build.

## What 0.3.0 actually contains

- Main mod entry point and a registered Forge common configuration file.
- Client-side, read-only performance diagnostics: client tick timing, render-event timing, JVM memory, garbage-collector deltas, and client chunk load/unload event counts. Diagnostics are disabled by default and do not alter game simulation.
- A production-adapter API foundation for future explicitly supported machine integrations.
- Separate Torcherino addon entry point and optional mod-presence detection.

## What it does NOT contain yet

- No FPS, chunk scheduling, entity, particle, or machine-speed optimization is implemented yet. The 0.3.0 diagnostics measure activity; they do not optimize it.
- The Torcherino addon does not intercept accelerated ticks or multiply machine output.
- No compatibility with Draconic Evolution or other machine mods is claimed.
- No compiled JAR is included.

## Build requirements

Use JDK 17 and Gradle with internet access to resolve ForgeGradle and Forge dependencies. The Gradle wrapper is not included.

Main mod, from this folder: `gradle build`

Torcherino addon, from `torcherino-compat/`: `gradle build`

## Testing rules

1. Back up worlds and test in a copied profile.
2. Build and install the main mod alone first.
3. Build and install the addon alone next; it should load even if Torcherino is absent.
4. Only then test the addon with the exact Torcherino build.
5. Do not remove existing mods or libraries based on this development build.

This source has not been compiled or tested in PojavLauncher/LTW. The diagnostic output is intended to help identify bottlenecks before enabling behavior-changing optimizations.

## Compilação automática pelo GitHub Actions

Este projeto inclui `.github/workflows/build.yml`. Depois de enviar a pasta `up020fix` para um repositório GitHub, abra a aba **Actions**, selecione **Build ULTRA PERFORMANCE** e use **Run workflow**. O fluxo configura Java 17 e Gradle 8.8, compila o mod principal e, separadamente, o addon Torcherino, e publica os JARs em **Artifacts**.

A compilação em nuvem ainda precisa ser executada; a presença do workflow não significa que os JARs já foram compilados ou testados no Minecraft.


## 0.3.0 diagnostics

To enable diagnostics, launch Minecraft once so Forge creates the config file, then edit `config/ultra_performance-common.toml` and set `diagnosticsEnabled = true`. The summary is written to the game log at the configured interval. Keep diagnostics disabled for ordinary play if you do not need measurements.

The measurements are observational, not a promise of higher FPS. Render-event timing is an approximate client render-loop measurement, not a GPU-only benchmark. Chunk counters report Forge client chunk load/unload events observed by this mod.
