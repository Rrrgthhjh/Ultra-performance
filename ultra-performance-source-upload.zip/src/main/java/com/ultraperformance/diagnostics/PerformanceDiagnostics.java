package com.ultraperformance.diagnostics;

import com.mojang.logging.LogUtils;
import com.ultraperformance.UltraPerformance;
import com.ultraperformance.config.UPConfig;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Read-only diagnostics for the client. This class intentionally does not
 * change chunk scheduling, rendering, game ticks, or garbage collection.
 */
@Mod.EventBusSubscriber(modid = UltraPerformance.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PerformanceDiagnostics {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final AtomicLong CLIENT_CHUNKS_LOADED = new AtomicLong();
    private static final AtomicLong CLIENT_CHUNKS_UNLOADED = new AtomicLong();
    private static final AtomicLong SERVER_CHUNKS_LOADED = new AtomicLong();
    private static final AtomicLong SERVER_CHUNKS_UNLOADED = new AtomicLong();
    private static final AtomicLong BLOCKS_BROKEN = new AtomicLong();
    private static final AtomicLong BLOCKS_PLACED = new AtomicLong();
    private static final AtomicLong ENTITIES_JOINED = new AtomicLong();
    private static final AtomicLong ITEM_ENTITIES_JOINED = new AtomicLong();

    private static long intervalStartNs = System.nanoTime();
    private static long clientTickStartNs;
    private static long renderStartNs;
    private static long tickSamples;
    private static long tickTotalNs;
    private static long tickMaxNs;
    private static long renderSamples;
    private static long renderTotalNs;
    private static long renderMaxNs;
    private static long serverTickStartNs;
    private static long serverTickSamples;
    private static long serverTickTotalNs;
    private static long serverTickMaxNs;
    private static long lastGcCount;
    private static long lastGcTimeMs;

    private PerformanceDiagnostics() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (!UPConfig.diagnosticsEnabled.get()) return;

        if (event.phase == TickEvent.Phase.START) {
            clientTickStartNs = System.nanoTime();
            return;
        }

        if (clientTickStartNs != 0L) {
            long elapsed = System.nanoTime() - clientTickStartNs;
            tickSamples++;
            tickTotalNs += elapsed;
            tickMaxNs = Math.max(tickMaxNs, elapsed);
            clientTickStartNs = 0L;
        }

        long now = System.nanoTime();
        long intervalNs = UPConfig.diagnosticsIntervalSeconds.get() * 1_000_000_000L;
        if (now - intervalStartNs >= intervalNs) {
            logSummary(now);
        }
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (!UPConfig.diagnosticsEnabled.get()) return;

        if (event.phase == TickEvent.Phase.START) {
            renderStartNs = System.nanoTime();
        } else if (renderStartNs != 0L) {
            long elapsed = System.nanoTime() - renderStartNs;
            renderSamples++;
            renderTotalNs += elapsed;
            renderMaxNs = Math.max(renderMaxNs, elapsed);
            renderStartNs = 0L;
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (!UPConfig.diagnosticsEnabled.get()) return;

        if (event.phase == TickEvent.Phase.START) {
            serverTickStartNs = System.nanoTime();
            return;
        }

        if (serverTickStartNs != 0L) {
            long elapsed = System.nanoTime() - serverTickStartNs;
            serverTickSamples++;
            serverTickTotalNs += elapsed;
            serverTickMaxNs = Math.max(serverTickMaxNs, elapsed);
            serverTickStartNs = 0L;
        }
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (UPConfig.diagnosticsEnabled.get() && !event.getLevel().isClientSide()) {
            BLOCKS_BROKEN.incrementAndGet();
        }
    }

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (UPConfig.diagnosticsEnabled.get() && !event.getLevel().isClientSide()) {
            BLOCKS_PLACED.incrementAndGet();
        }
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!UPConfig.diagnosticsEnabled.get() || event.getLevel().isClientSide()) return;
        ENTITIES_JOINED.incrementAndGet();
        if (event.getEntity() instanceof ItemEntity) {
            ITEM_ENTITIES_JOINED.incrementAndGet();
        }
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (!UPConfig.diagnosticsEnabled.get()) return;
        if (event.getLevel().isClientSide()) {
            CLIENT_CHUNKS_LOADED.incrementAndGet();
        } else {
            SERVER_CHUNKS_LOADED.incrementAndGet();
        }
    }

    @SubscribeEvent
    public static void onChunkUnload(ChunkEvent.Unload event) {
        if (!UPConfig.diagnosticsEnabled.get()) return;
        if (event.getLevel().isClientSide()) {
            CLIENT_CHUNKS_UNLOADED.incrementAndGet();
        } else {
            SERVER_CHUNKS_UNLOADED.incrementAndGet();
        }
    }

    private static void logSummary(long now) {
        Runtime runtime = Runtime.getRuntime();
        long usedMiB = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L);
        long committedMiB = runtime.totalMemory() / (1024L * 1024L);
        long maxMiB = runtime.maxMemory() / (1024L * 1024L);

        long gcCount = 0L;
        long gcTimeMs = 0L;
        List<GarbageCollectorMXBean> collectors = ManagementFactory.getGarbageCollectorMXBeans();
        for (GarbageCollectorMXBean collector : collectors) {
            if (collector.getCollectionCount() >= 0) gcCount += collector.getCollectionCount();
            if (collector.getCollectionTime() >= 0) gcTimeMs += collector.getCollectionTime();
        }

        long gcCountDelta = lastGcCount == 0L ? 0L : gcCount - lastGcCount;
        long gcTimeDelta = lastGcTimeMs == 0L ? 0L : gcTimeMs - lastGcTimeMs;
        lastGcCount = gcCount;
        lastGcTimeMs = gcTimeMs;

        double tickAvgMs = tickSamples == 0 ? 0.0 : (tickTotalNs / 1_000_000.0) / tickSamples;
        double renderAvgMs = renderSamples == 0 ? 0.0 : (renderTotalNs / 1_000_000.0) / renderSamples;
        double seconds = Math.max(0.001, (now - intervalStartNs) / 1_000_000_000.0);
        long loaded = CLIENT_CHUNKS_LOADED.getAndSet(0L);
        long unloaded = CLIENT_CHUNKS_UNLOADED.getAndSet(0L);
        long serverLoaded = SERVER_CHUNKS_LOADED.getAndSet(0L);
        long serverUnloaded = SERVER_CHUNKS_UNLOADED.getAndSet(0L);
        long broken = BLOCKS_BROKEN.getAndSet(0L);
        long placed = BLOCKS_PLACED.getAndSet(0L);
        long entities = ENTITIES_JOINED.getAndSet(0L);
        long itemEntities = ITEM_ENTITIES_JOINED.getAndSet(0L);
        double serverTickAvgMs = serverTickSamples == 0 ? 0.0 :
                (serverTickTotalNs / 1_000_000.0) / serverTickSamples;

        LOGGER.info("[ULTRA PERFORMANCE] Diagnostics ({}s): memory used/committed/max={} / {} / {} MiB; " +
                        "client tick avg/max={} / {} ms ({} samples); server tick avg/max={} / {} ms ({} samples); " +
                        "render avg/max={} / {} ms ({} samples); GC count/time={} / {} ms; " +
                        "chunks client load/unload={}/{} server load/unload={}/{}; " +
                        "blocks broken/placed={}/{}; entities joined={} (items={})",
                String.format(java.util.Locale.ROOT, "%.1f", seconds),
                usedMiB, committedMiB, maxMiB,
                formatMs(tickAvgMs), formatMs(tickMaxNs / 1_000_000.0), tickSamples,
                formatMs(serverTickAvgMs), formatMs(serverTickMaxNs / 1_000_000.0), serverTickSamples,
                formatMs(renderAvgMs), formatMs(renderMaxNs / 1_000_000.0), renderSamples,
                gcCountDelta, gcTimeDelta,
                loaded, unloaded, serverLoaded, serverUnloaded,
                broken, placed, entities, itemEntities);

        tickSamples = tickTotalNs = tickMaxNs = 0L;
        serverTickSamples = serverTickTotalNs = serverTickMaxNs = 0L;
        renderSamples = renderTotalNs = renderMaxNs = 0L;
        intervalStartNs = now;
    }

    private static String formatMs(double value) {
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }
}
