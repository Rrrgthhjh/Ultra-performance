package com.ultraperformance.diagnostics;

import com.mojang.logging.LogUtils;
import com.ultraperformance.UltraPerformance;
import com.ultraperformance.config.UPConfig;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Read-only diagnostic sampling. Counters are interval-based and do not
 * alter world simulation, scheduling, rendering settings, or garbage collection.
 */
@Mod.EventBusSubscriber(modid = UltraPerformance.MOD_ID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PerformanceDiagnostics {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final AtomicLong CLIENT_CHUNKS_LOADED = new AtomicLong();
    private static final AtomicLong CLIENT_CHUNKS_UNLOADED = new AtomicLong();
    private static final AtomicLong SERVER_CHUNKS_LOADED = new AtomicLong();
    private static final AtomicLong SERVER_CHUNKS_UNLOADED = new AtomicLong();

    private static final AtomicLong SERVER_BLOCK_BREAKS = new AtomicLong();
    private static final AtomicLong SERVER_BLOCK_PLACES = new AtomicLong();
    private static final AtomicLong CLIENT_BLOCK_BREAKS = new AtomicLong();
    private static final AtomicLong CLIENT_BLOCK_PLACES = new AtomicLong();

    private static final AtomicLong ENTITIES_JOINED = new AtomicLong();
    private static final AtomicLong ENTITIES_LEFT = new AtomicLong();
    private static final AtomicLong MOBS_JOINED = new AtomicLong();
    private static final AtomicLong ANIMALS_JOINED = new AtomicLong();
    private static final AtomicLong ITEMS_JOINED = new AtomicLong();
    private static final AtomicLong PROJECTILES_JOINED = new AtomicLong();
    private static final AtomicLong ENTITY_RENDER_CULLED = new AtomicLong();

    private static final AtomicLong CURRENT_ENTITIES = new AtomicLong();
    private static final AtomicLong CURRENT_MOBS = new AtomicLong();
    private static final AtomicLong CURRENT_ANIMALS = new AtomicLong();
    private static final AtomicLong CURRENT_ITEMS = new AtomicLong();
    private static final AtomicLong CURRENT_PROJECTILES = new AtomicLong();

    private static long intervalStartNs = System.nanoTime();
    private static long clientTickStartNs;
    private static long serverTickStartNs;
    private static long renderTickStartNs;

    private static final Timing CLIENT_TICKS = new Timing();
    private static final Timing SERVER_TICKS = new Timing();
    private static final Timing RENDER_TICKS = new Timing();

    private static long previousGcCount = -1L;
    private static long previousGcTimeMs = -1L;

    private PerformanceDiagnostics() {}

    /** Called by the client render hook whenever a living entity is hidden by UP. */
    public static void recordEntityRenderCulled() {
        if (enabled()) ENTITY_RENDER_CULLED.incrementAndGet();
    }

    private static boolean enabled() {
        return UPConfig.diagnosticsEnabled.get();
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (!enabled()) return;
        if (event.phase == TickEvent.Phase.START) {
            clientTickStartNs = System.nanoTime();
            return;
        }
        if (clientTickStartNs != 0L) {
            CLIENT_TICKS.add(System.nanoTime() - clientTickStartNs);
            clientTickStartNs = 0L;
        }
        long now = System.nanoTime();
        long interval = UPConfig.diagnosticsIntervalSeconds.get() * 1_000_000_000L;
        if (now - intervalStartNs >= interval) {
            logSummary(now);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (!enabled()) return;
        if (event.phase == TickEvent.Phase.START) {
            serverTickStartNs = System.nanoTime();
        } else if (serverTickStartNs != 0L) {
            SERVER_TICKS.add(System.nanoTime() - serverTickStartNs);
            serverTickStartNs = 0L;
        }
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (!enabled()) return;
        if (event.phase == TickEvent.Phase.START) {
            renderTickStartNs = System.nanoTime();
        } else if (renderTickStartNs != 0L) {
            RENDER_TICKS.add(System.nanoTime() - renderTickStartNs);
            renderTickStartNs = 0L;
        }
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!enabled()) return;
        if (event.getLevel().isClientSide()) CLIENT_BLOCK_BREAKS.incrementAndGet();
        else SERVER_BLOCK_BREAKS.incrementAndGet();
    }

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!enabled()) return;
        if (event.getLevel().isClientSide()) CLIENT_BLOCK_PLACES.incrementAndGet();
        else SERVER_BLOCK_PLACES.incrementAndGet();
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!enabled() || event.getLevel().isClientSide()) return;
        var entity = event.getEntity();
        ENTITIES_JOINED.incrementAndGet();
        CURRENT_ENTITIES.incrementAndGet();
        if (entity instanceof Mob) {
            MOBS_JOINED.incrementAndGet();
            CURRENT_MOBS.incrementAndGet();
        }
        if (entity instanceof Animal) {
            ANIMALS_JOINED.incrementAndGet();
            CURRENT_ANIMALS.incrementAndGet();
        }
        if (entity instanceof ItemEntity) {
            ITEMS_JOINED.incrementAndGet();
            CURRENT_ITEMS.incrementAndGet();
        }
        if (entity instanceof Projectile) {
            PROJECTILES_JOINED.incrementAndGet();
            CURRENT_PROJECTILES.incrementAndGet();
        }
    }

    @SubscribeEvent
    public static void onEntityLeave(EntityLeaveLevelEvent event) {
        if (!enabled() || event.getLevel().isClientSide()) return;
        var entity = event.getEntity();
        ENTITIES_LEFT.incrementAndGet();
        decrement(CURRENT_ENTITIES);
        if (entity instanceof Mob) decrement(CURRENT_MOBS);
        if (entity instanceof Animal) decrement(CURRENT_ANIMALS);
        if (entity instanceof ItemEntity) decrement(CURRENT_ITEMS);
        if (entity instanceof Projectile) decrement(CURRENT_PROJECTILES);
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (!enabled()) return;
        if (event.getLevel().isClientSide()) CLIENT_CHUNKS_LOADED.incrementAndGet();
        else SERVER_CHUNKS_LOADED.incrementAndGet();
    }

    @SubscribeEvent
    public static void onChunkUnload(ChunkEvent.Unload event) {
        if (!enabled()) return;
        if (event.getLevel().isClientSide()) CLIENT_CHUNKS_UNLOADED.incrementAndGet();
        else SERVER_CHUNKS_UNLOADED.incrementAndGet();
    }

    private static void decrement(AtomicLong value) {
        value.updateAndGet(current -> Math.max(0L, current - 1L));
    }

    private static void logSummary(long now) {
        Runtime runtime = Runtime.getRuntime();
        long usedMiB = (runtime.totalMemory() - runtime.freeMemory()) / 1048576L;
        long committedMiB = runtime.totalMemory() / 1048576L;
        long maxMiB = runtime.maxMemory() / 1048576L;

        long gcCount = 0L;
        long gcTimeMs = 0L;
        List<GarbageCollectorMXBean> collectors = ManagementFactory.getGarbageCollectorMXBeans();
        for (GarbageCollectorMXBean collector : collectors) {
            if (collector.getCollectionCount() >= 0) gcCount += collector.getCollectionCount();
            if (collector.getCollectionTime() >= 0) gcTimeMs += collector.getCollectionTime();
        }
        long gcCountDelta = previousGcCount < 0 ? 0 : Math.max(0, gcCount - previousGcCount);
        long gcTimeDelta = previousGcTimeMs < 0 ? 0 : Math.max(0, gcTimeMs - previousGcTimeMs);
        previousGcCount = gcCount;
        previousGcTimeMs = gcTimeMs;

        ThreadMXBean threads = ManagementFactory.getThreadMXBean();
        int liveThreads = threads.getThreadCount();
        int peakThreads = threads.getPeakThreadCount();

        double seconds = Math.max(0.001, (now - intervalStartNs) / 1_000_000_000.0);

        LOGGER.info("[ULTRA PERFORMANCE] DIAGNOSTICS v0.5.0 ({}s) " +
                "JVM heap used/committed/max={} / {} / {} MiB; threads live/peak={}/{}; " +
                "clientTicks {}; serverTicks {}; renderTickProxy {}; " +
                "GC interval count/time={}/{}ms; " +
                "chunks client load/unload={}/{} server load/unload={}/{}; " +
                "entityRenderCulled={}; " +
                "blocks client break/place={}/{} server break/place={}/{}; " +
                "entities join/leave={}/{} current={} mobs={} animals={} items={} projectiles={}; " +
                "joined interval mobs={} animals={} items={} projectiles={}",
                format(seconds), usedMiB, committedMiB, maxMiB, liveThreads, peakThreads,
                CLIENT_TICKS.describe(), SERVER_TICKS.describe(), RENDER_TICKS.describe(),
                gcCountDelta, gcTimeDelta,
                CLIENT_CHUNKS_LOADED.getAndSet(0), CLIENT_CHUNKS_UNLOADED.getAndSet(0),
                SERVER_CHUNKS_LOADED.getAndSet(0), SERVER_CHUNKS_UNLOADED.getAndSet(0),
                ENTITY_RENDER_CULLED.getAndSet(0),
                CLIENT_BLOCK_BREAKS.getAndSet(0), CLIENT_BLOCK_PLACES.getAndSet(0),
                SERVER_BLOCK_BREAKS.getAndSet(0), SERVER_BLOCK_PLACES.getAndSet(0),
                ENTITIES_JOINED.getAndSet(0), ENTITIES_LEFT.getAndSet(0),
                CURRENT_ENTITIES.get(), CURRENT_MOBS.get(), CURRENT_ANIMALS.get(),
                CURRENT_ITEMS.get(), CURRENT_PROJECTILES.get(),
                MOBS_JOINED.getAndSet(0), ANIMALS_JOINED.getAndSet(0),
                ITEMS_JOINED.getAndSet(0), PROJECTILES_JOINED.getAndSet(0));

        LOGGER.info("[ULTRA PERFORMANCE] ENV java={} vm={} os={} arch={} processors={}",
                System.getProperty("java.version", "unknown"),
                System.getProperty("java.vm.name", "unknown"),
                System.getProperty("os.name", "unknown"),
                System.getProperty("os.arch", "unknown"),
                Runtime.getRuntime().availableProcessors());

        CLIENT_TICKS.reset();
        SERVER_TICKS.reset();
        RENDER_TICKS.reset();
        intervalStartNs = now;
    }

    private static String format(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    /** Fixed-size sample buffer. Sampling performs no per-tick allocations. */
    private static final class Timing {
        private static final int SAMPLE_CAPACITY = 2048;
        private final long[] samples = new long[SAMPLE_CAPACITY];
        private int sampleCount;
        private int nextSample;
        private long count;
        private long totalNs;
        private long maxNs;
        private long over50;
        private long over100;
        private long over250;
        private long over500;
        private long over1000;

        void add(long ns) {
            count++;
            totalNs += ns;
            maxNs = Math.max(maxNs, ns);
            samples[nextSample] = ns;
            nextSample = (nextSample + 1) % SAMPLE_CAPACITY;
            if (sampleCount < SAMPLE_CAPACITY) sampleCount++;
            double ms = ns / 1_000_000.0;
            if (ms > 50) over50++;
            if (ms > 100) over100++;
            if (ms > 250) over250++;
            if (ms > 500) over500++;
            if (ms > 1000) over1000++;
        }

        String describe() {
            double avg = count == 0 ? 0 : (totalNs / 1_000_000.0) / count;
            long[] ordered = new long[sampleCount];
            System.arraycopy(samples, 0, ordered, 0, sampleCount);
            java.util.Arrays.sort(ordered);
            double p95 = percentileMs(ordered, 0.95);
            double p99 = percentileMs(ordered, 0.99);
            return "avg/max=" + format(avg) + "/" + format(maxNs / 1_000_000.0) +
                    "ms p95/p99=" + format(p95) + "/" + format(p99) +
                    "ms samples=" + count + " sampled=" + sampleCount +
                    " >50/100/250/500/1000ms=" +
                    over50 + "/" + over100 + "/" + over250 + "/" + over500 + "/" + over1000;
        }

        private static double percentileMs(long[] sorted, double percentile) {
            if (sorted.length == 0) return 0;
            int index = (int) Math.ceil(percentile * sorted.length) - 1;
            index = Math.max(0, Math.min(index, sorted.length - 1));
            return sorted[index] / 1_000_000.0;
        }

        void reset() {
            count = totalNs = maxNs = over50 = over100 = over250 = over500 = over1000 = 0L;
            sampleCount = 0;
            nextSample = 0;
        }
    }
}
