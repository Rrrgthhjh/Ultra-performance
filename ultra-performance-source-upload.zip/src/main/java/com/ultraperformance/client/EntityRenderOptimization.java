package com.ultraperformance.client;

import com.ultraperformance.UltraPerformance;
import com.ultraperformance.config.UPConfig;
import com.ultraperformance.diagnostics.PerformanceDiagnostics;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only visual optimization: it never pauses or changes entity simulation. */
@Mod.EventBusSubscriber(modid = UltraPerformance.MOD_ID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class EntityRenderOptimization {
    private EntityRenderOptimization() {}

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre<?, ?> event) {
        if (!UPConfig.distantEntityRenderCulling.get()) return;
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player) return;

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) return;
        if (entity.level() != minecraft.level) return;

        double distance = UPConfig.entityRenderDistance.get();
        if (entity.distanceToSqr(minecraft.player) > distance * distance) {
            event.setCanceled(true);
            PerformanceDiagnostics.recordEntityRenderCulled();
        }
    }
}
