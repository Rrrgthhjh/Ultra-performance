package com.ultraperformance.client;

import net.minecraft.client.gui.GuiGraphics;
import com.ultraperformance.config.UPConfig;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;

/** Small configuration screen opened from Forge's Mods list. */
public final class UPConfigScreen extends Screen {
    private final Screen parent;
    private Button cullingButton;
    private Button distanceButton;

    public UPConfigScreen(Screen parent) {
        super(Component.literal("ULTRA PERFORMANCE"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int y = this.height / 4;
        cullingButton = this.addRenderableWidget(Button.builder(cullingLabel(), button -> {
            UPConfig.distantEntityRenderCulling.set(!UPConfig.distantEntityRenderCulling.get());
            button.setMessage(cullingLabel());
            saveConfig();
        }).bounds(center - 125, y, 250, 20).build());

        distanceButton = this.addRenderableWidget(Button.builder(distanceLabel(), button -> {
            int current = UPConfig.entityRenderDistance.get();
            int next = current >= 128 ? 32 : current + 16;
            UPConfig.entityRenderDistance.set(next);
            button.setMessage(distanceLabel());
            saveConfig();
        }).bounds(center - 125, y + 28, 250, 20).build());

        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> this.onClose())
                .bounds(center - 100, y + 72, 200, 20).build());
    }

    private static Component cullingLabel() {
        return Component.literal("Culling de entidades distantes: " +
                (UPConfig.distantEntityRenderCulling.get() ? "ATIVADO" : "DESATIVADO"));
    }

    private static Component distanceLabel() {
        return Component.literal("Distância de renderização: " + UPConfig.entityRenderDistance.get() + " blocos");
    }

    private static void saveConfig() {
        ModConfig config = ModLoadingContext.get().getActiveContainer().getConfig(ModConfig.Type.COMMON);
        if (config != null) config.save();
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 4 - 24, 0xFFFFFF);
        guiGraphics.drawCenteredString(this.font,
                Component.literal("Otimização visual: não altera IA, farms ou ticks das entidades."),
                this.width / 2, this.height / 4 + 58, 0xA0A0A0);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
