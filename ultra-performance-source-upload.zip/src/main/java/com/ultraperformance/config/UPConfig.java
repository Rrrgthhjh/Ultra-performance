package com.ultraperformance.config;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Central configuration for Ultra Performance.
 * Defaults are deliberately conservative; future optimizers must be opt-in
 * until they have been tested against modded machines and client setups.
 */
public final class UPConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue diagnosticsEnabled;
    public static final ForgeConfigSpec.IntValue diagnosticsIntervalSeconds;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("general");
        diagnosticsEnabled = builder
                .comment("Enable lightweight diagnostic logging. This does not change game simulation.")
                .define("diagnosticsEnabled", false);
        diagnosticsIntervalSeconds = builder
                .comment("Minimum interval between diagnostic summaries, in seconds.")
                .defineInRange("diagnosticsIntervalSeconds", 30, 5, 600);
        builder.pop();

        SPEC = builder.build();
    }

    private UPConfig() {
    }
}
