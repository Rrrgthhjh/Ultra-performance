package com.ultraperformance.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuration for read-only diagnostics. */
public final class UPConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue diagnosticsEnabled;
    public static final ForgeConfigSpec.IntValue diagnosticsIntervalSeconds;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("general");
        diagnosticsEnabled = builder
                .comment("Enable read-only performance diagnostics. No game mechanics are changed.")
                .define("diagnosticsEnabled", true);
        diagnosticsIntervalSeconds = builder
                .comment("Seconds between diagnostic summaries.")
                .defineInRange("diagnosticsIntervalSeconds", 30, 10, 600);
        builder.pop();
        SPEC = builder.build();
    }

    private UPConfig() {}
}
