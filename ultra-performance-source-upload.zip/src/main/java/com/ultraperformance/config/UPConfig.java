package com.ultraperformance.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;

/** Configuration for diagnostics and the first opt-in rendering optimization. */
public final class UPConfig {
    public static final ForgeConfigSpec SPEC;
    private static ModConfig activeConfig;
    public static final ForgeConfigSpec.BooleanValue diagnosticsEnabled;
    public static final ForgeConfigSpec.IntValue diagnosticsIntervalSeconds;
    public static final ForgeConfigSpec.BooleanValue distantEntityRenderCulling;
    public static final ForgeConfigSpec.IntValue entityRenderDistance;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("general");
        diagnosticsEnabled = builder
                .comment("Enable read-only performance diagnostics.")
                .define("diagnosticsEnabled", true);
        diagnosticsIntervalSeconds = builder
                .comment("Seconds between diagnostic summaries.")
                .defineInRange("diagnosticsIntervalSeconds", 30, 10, 600);
        builder.pop();

        builder.push("rendering");
        distantEntityRenderCulling = builder
                .comment("Skip rendering distant non-player living entities. This does not stop their AI or world simulation.")
                .define("distantEntityRenderCulling", true);
        entityRenderDistance = builder
                .comment("Maximum distance in blocks for rendering non-player living entities when culling is enabled.")
                .defineInRange("entityRenderDistance", 64, 16, 256);
        builder.pop();
        SPEC = builder.build();
    }

    /** Capture the registered config object when Forge loads this mod config. */
    public static void onConfigEvent(ModConfigEvent event) {
        if (event.getConfig().getModId().equals("ultra_performance")
                && event.getConfig().getType() == ModConfig.Type.COMMON) {
            activeConfig = event.getConfig();
        }
    }

    /** Persist changes made through the in-game configuration screen. */
    public static void save() {
        if (activeConfig != null) {
            activeConfig.save();
        }
    }

    private UPConfig() {}
}
