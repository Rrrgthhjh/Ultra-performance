package com.ultraperformance.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuration for diagnostics and the first opt-in rendering optimization. */
public final class UPConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue diagnosticsEnabled;
    public static final ForgeConfigSpec.IntValue diagnosticsIntervalSeconds;
    public static final ForgeConfigSpec.BooleanValue distantEntityRenderCulling;
    public static final ForgeConfigSpec.IntValue entityRenderDistance;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("general");
        diagnosticsEnabled = builder
                .comment("Enable read-only performance diagnostics.")
                .define("diagnosticsEnabled", true);
        diagnosticsIntervalSeconds = builder
                .comment("Seconds between diagnostic summaries.")
                .defineInRange("diagnosticsIntervalSeconds", 30, 10, 600);
        builder.pop();

        builder.push("rendering");
        distantEntityRenderCulling = builder
                .comment("Skip rendering distant non-player living entities. This does not stop their AI or world simulation.")
                .define("distantEntityRenderCulling", true);
        entityRenderDistance = builder
                .comment("Maximum distance in blocks for rendering non-player living entities when culling is enabled.")
                .defineInRange("entityRenderDistance", 64, 16, 256);
        builder.pop();
        SPEC = builder.build();
    }

    private UPConfig() {}
}
