package com.ultraperformance.config;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Central configuration for Ultra Performance.
 * Defaults are deliberately conservative; future optimizers must be opt-in
 * until they have been tested against modded machines and client setups.
 */
public final class UPConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue diagnosticsEnabled;
    public static final ForgeConfigSpec.IntValue diagnosticsIntervalSeconds;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("general");
        diagnosticsEnabled = builder
                .comment("Enable lightweight client performance diagnostics. This records timings and memory; it does not change game simulation. Enabled by default in 0.3.1 to verify diagnostics during testing.")
                .define("diagnosticsEnabled", true);
        diagnosticsIntervalSeconds = builder
                .comment("Interval between diagnostic summaries, in seconds.")
                .defineInRange("diagnosticsIntervalSeconds", 10, 5, 600);
        builder.pop();

        SPEC = builder.build();
    }

    private UPConfig() {
    }
}
