package com.ultraperformance.api;

/**
 * Opt-in integration point for a supported machine family.
 * Implementations must validate recipes, inputs, energy, output space and
 * non-item side effects before committing a batch.
 */
public interface ProductionAdapter<T> {
    boolean supports(T machine);
    ProductionRequest inspect(T machine, long requestedOperations);
    boolean commit(T machine, long safeOperations);
}
