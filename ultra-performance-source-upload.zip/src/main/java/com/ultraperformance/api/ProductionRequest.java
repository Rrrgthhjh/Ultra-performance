package com.ultraperformance.api;

/**
 * Immutable request describing a proposed batch. This class does not execute
 * machine recipes; a machine-specific adapter must validate all side effects.
 */
public record ProductionRequest(long requestedOperations, long inputLimitedOperations,
                                long energyLimitedOperations, long outputLimitedOperations) {
    public ProductionRequest {
        if (requestedOperations < 0 || inputLimitedOperations < 0
                || energyLimitedOperations < 0 || outputLimitedOperations < 0) {
            throw new IllegalArgumentException("Operation limits cannot be negative");
        }
    }

    /** Safest upper bound known to the adapter. */
    public long safeOperations() {
        return Math.min(requestedOperations,
                Math.min(inputLimitedOperations,
                Math.min(energyLimitedOperations, outputLimitedOperations)));
    }
}
