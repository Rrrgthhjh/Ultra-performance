package com.ultraperformance;

import com.ultraperformance.config.UPConfig;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** Main mod. It is intentionally independent of Torcherino. */
@Mod(UltraPerformance.MOD_ID)
public final class UltraPerformance {
    public static final String MOD_ID = "ultra_performance";

    public UltraPerformance() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, UPConfig.SPEC);
    }
}
