# Changelog

## 0.3.4
- Added sampled p95 and p99 timing values for client, integrated-server, and render-tick proxy measurements.
- Uses a fixed-size sample buffer and performs sorting only when a diagnostic summary is written, not on every tick.
- No gameplay, world simulation, scheduling, or rendering settings are changed.
- Torcherino compatibility addon remains independent and unchanged at 0.2.2.

## 0.3.3
- Expanded read-only diagnostics for ticks, chunks, blocks, entities, JVM memory, garbage collection, and threads.
