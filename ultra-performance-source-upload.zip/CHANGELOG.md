# ULTRA PERFORMANCE 0.4.0

## First optimization: distant living-entity render culling
- Adds a client-side visual optimization that skips rendering non-player living entities beyond a configurable distance.
- Does not cancel entity ticks, AI, movement, collision, despawning, block updates, or server simulation.
- Default: enabled, 64-block range. Players are never culled.
- Adds a Forge mod configuration screen with a toggle and distance cycle (32–128 blocks).
- Existing read-only diagnostics retained and version-stamped as 0.4.0.
- Torcherino compatibility project is unchanged and remains separate.

This optimization may reduce rendering work in scenes containing many distant living entities, but it is not guaranteed to increase FPS on every device or world. It intentionally trades distant entity visibility for potential rendering savings.

## 0.4.0-fix2
- Fixed configuration saving: capture the registered COMMON ModConfig through Forge's ModConfigEvent on the mod event bus, then call ModConfig.save() from the configuration screen.
- Removed the unsupported ModContainer.getConfig(ModConfig.Type) call.
