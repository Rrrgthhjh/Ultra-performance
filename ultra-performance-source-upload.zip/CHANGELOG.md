# Changelog

## 0.3.0
- Added opt-in, read-only client diagnostics.
- Measures client tick duration and render-event duration.
- Reports JVM used/committed/maximum heap memory.
- Reports garbage collector count/time deltas.
- Counts client chunk load/unload events.
- No behavior-changing optimizations are enabled in this milestone.
- Torcherino compatibility addon remains a separate project and is unchanged.
