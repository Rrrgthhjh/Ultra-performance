# Changelog

## 0.3.0
- Added opt-in, read-only client diagnostics.
- Measures client tick duration and render-event duration.
- Reports JVM used/committed/maximum heap memory.
- Reports garbage collector count/time deltas.
- Counts client chunk load/unload events.
- No behavior-changing optimizations are enabled in this milestone.
- Torcherino compatibility addon remains a separate project and is unchanged.

## 0.3.1 (maintenance build)
- Enabled read-only diagnostics by default so the first test actually records measurements.
- Shortened the default reporting interval from 30 to 10 seconds to capture short exploration sessions.
- No gameplay or chunk-loading behavior is modified.

## 0.3.3 - Diagnostic expansion
- Added entity leave tracking and current entity category estimates.
- Split client/server block event counters.
- Added tick threshold counters (>50, >100, >250, >500, >1000 ms).
- Added JVM thread counts and environment metadata.
- Increased default reporting interval to 30 seconds to reduce log overhead.
- No gameplay or optimization behavior changed.
