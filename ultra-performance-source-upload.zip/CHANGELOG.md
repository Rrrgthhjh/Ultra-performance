# ULTRA PERFORMANCE 0.5.0

## Diagnostic improvements
- Adds `entityRenderCulled` to each diagnostic interval: the number of non-player living-entity render events canceled by UP's distance culling. This measures how often the optimization activates, not saved milliseconds or FPS.
- Keeps separate client/server chunk load and unload event counters. These are event counts, not direct chunk-generation timings.
- Updates the diagnostic and mod version labels to 0.5.0.

## Existing optimization
- Retains the 0.4.0 distant living-entity render culling behavior and configuration.
- Does not change chunk loading/generation, entity AI, world simulation, or server tick scheduling.

## Important limitations
Minecraft/Forge's chunk load events do not by themselves tell us how long terrain generation took. This release improves correlation data but does not claim to speed up chunk loading. A separate, controlled test is needed before claiming performance gains.

## Addon
- `torcherino-compat` remains separate and unchanged.
